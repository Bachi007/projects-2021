#City Administration Project



Installation :
----------------
1. Activate virtual environment 


Enter into "" folder >> Run the following commands

3. py manage.py makemigrations    	// it will generate the sql code to create tables in database
4. py manage.py migrate 		// it will execute the generated code
5. py manage.py runserver 		// it will starts the server

goto any browser : Open the bellow Link
 
http://127.0.0.1:8000/

Administrator user example cridentials : 
----------
username : admin
password : admin


Demo user :
----------------
user email : demouser@gmail.com
password : pass@demo