from django.contrib import admin
from home.models import tollgatedb
# Register your models here.

class tollgatedbAdmin(admin.ModelAdmin):
    list_display=["username","vehicleno","vehiclename","src","dest","charge","date","journy"]

admin.site.register(tollgatedb,tollgatedbAdmin)
