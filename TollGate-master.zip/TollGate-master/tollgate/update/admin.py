from django.contrib import admin
from update.models import updatedb
# Register your models here.

class updatedbAdmin(admin.ModelAdmin):
    list_display=["vehicle","amount"]


admin.site.register(updatedb,updatedbAdmin)
