from django.apps import AppConfig


class AdminuserConfig(AppConfig):
    name = 'adminuser'
