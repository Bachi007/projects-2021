from django.contrib import admin
from registration.models import logindb1
# Register your models here.

class logindb1Admin(admin.ModelAdmin):
    list_display=["username","password","location","lane"]

admin.site.register(logindb1,logindb1Admin)
