#Tollgate Management System using Python
--------------------------------
Tollgate Management System is a system which is devoloped by python and django, to provide better interaction between tollgate manager and vehicle user to store
all the information from user and retrive that data from database.

MODULES :
----------

1. SuperUser module / database Module
2. Admin module
3. User module
-------------------------------------------------------
1. SuperUser module / database Module

The Django admin application can use your models to automatically build a site area that you can use to create, view, update, and delete 
records. This can save you a lot of time during development, making it very easy to test your models and get a feel for whether you have 
the right data. The admin application can also be useful for managing data in production, depending on the type of website. The Django 
project recommends it only for internal data management (i.e. just for use by tollgate admin), 
as the model-centric approach is not necessarily the best possible interface for all users, and exposes a lot of unnecessary detail about the models. 
--------------------------------------------------------
2. Admin module

This module gives head related functionalities. The admin can see the enlisted client and installment model and set the sum 
and vehicle sort and refresh the sum in the administrator installment mode see the client subtle elements data in the database.
admin can retrive the data like user details and transport passengers details and add the users for user module.admin can view the total amount 
in the date wise and source to destination wise report. he also have access to delete user.
------------------------------------------------------
3. User module

user is need to login with the cridentials given by the admin.
In this module new user can view his profile and his transport details through places, vehicles, dates view.


Installation :
----------------
1. Activate virtual environment 

Enter into "tollgate" folder >> Run the following commands

2. py manage.py makemigrations
3. py manage.py migrate
4. py manage.py runserver

goto any browser : Open the bellow Link
 
http://127.0.0.1:8000/adminuser/login/

admin : 
----------
username : pmbs
password : pmbs123

end user : 
--------------
username : siva
password : siva123