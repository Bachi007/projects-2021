#Student Alumni



Installation :
----------------
1. Activate virtual environment 

Enter into "" folder >> Run the following commands

2. py manage.py makemigrations
3. py manage.py migrate
4. py manage.py runserver

goto any browser : Open the bellow Link
 
http://127.0.0.1:8000/

Blog user example cridentials : 
----------
usermail : demostudent@gmail.com
password : pass@demo
