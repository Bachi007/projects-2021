#Student Management System



Installation :
----------------
1. Activate virtual environment 

Enter into "django-student-management-system-master" folder >> Run the following commands

2. py manage.py makemigrations
3. py manage.py migrate
4. py manage.py runserver

goto any browser : Open the bellow Link
 
http://127.0.0.1:8000/

example cridentials : 
----------
HOD Login : 
----------------
usermail : admin@gmail.com
password : admin

Teacher Login : 
--------------
usermail : teacher@gmail.com
password : teacher


Student Login : 
---------------
usermail : student@gmail.com
password : student

